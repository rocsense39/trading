from __future__ import annotations

import argparse
import time
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

from bot.config_loader import load_config
from bot.state import load_state, save_state, daily_entry_allowed, mark_daily_entry
from bot.regime import classify_regime
from bot.portfolio import build_portfolio, reserve_eur, deployable_cash_eur
from bot.strategy import choose_candidate
from bot.risk import make_order_plan
from bot.reporting import send_telegram, portfolio_report, order_message

ROOT = Path(__file__).resolve().parent
DEFAULT_CONFIG = ROOT / "config" / "config.json"
DEFAULT_STATE = ROOT / "state.json"


def run_once(config_path: Path, state_path: Path) -> None:
    cfg = load_config(config_path)
    state = load_state(state_path)
    tz_name = cfg["settings"].get("timezone", "Europe/Berlin")

    regime, regime_score, details = classify_regime(cfg)
    print(f"Regime: {regime} score={regime_score} | {details}")

    views, portfolio_value = build_portfolio(cfg)
    send_telegram(portfolio_report(views, portfolio_value, regime, regime_score, details))

    if not daily_entry_allowed(cfg, state):
        print("Daily entry already used. No new buy.")
        return

    candidate = choose_candidate(cfg, views, regime, regime_score)
    if candidate is None:
        print("No valid candidate.")
        return

    reserve = reserve_eur(cfg, portfolio_value)
    deployable = deployable_cash_eur(cfg, portfolio_value)
    amount = min(candidate.view.gap_eur, deployable, float(cfg["settings"]["max_order_eur"]))
    min_order = float(cfg["settings"]["min_order_eur"])

    if amount < min_order:
        print(
            f"{candidate.name}: rejected — order {amount:.2f} EUR below min_order_eur {min_order:.2f}; "
            f"free_cash={float(cfg['settings']['free_cash_eur']):.2f}, reserve={reserve:.2f}, "
            f"deployable={deployable:.2f}, gap={candidate.view.gap_eur:.2f}"
        )
        return

    plan = make_order_plan(candidate.view, amount)
    if plan.reward_risk is not None and plan.reward_risk < 1.25:
        print(f"{candidate.name}: rejected — reward/risk {plan.reward_risk:.2f} below 1.25")
        return

    send_telegram(order_message(candidate.name, candidate.view, plan, regime, regime_score, details, portfolio_value, reserve, deployable))
    mark_daily_entry(cfg, state, candidate.name)
    save_state(state_path, state)


def run_loop(config_path: Path, state_path: Path) -> None:
    cfg = load_config(config_path)
    tz = ZoneInfo(cfg["settings"].get("timezone", "Europe/Berlin"))
    sleep_seconds = int(cfg["settings"].get("sleep_seconds", 900))
    send_telegram("✅ <b>ETF Bot V4 started</b>\nClean config. Portfolio-first. Mandatory SL/TP discipline.")
    while True:
        print(f"[{datetime.now(tz).strftime('%Y-%m-%d %H:%M:%S %Z')}] scan")
        try:
            run_once(config_path, state_path)
        except Exception as exc:
            print(f"Run error: {exc}")
            send_telegram(f"🔴 <b>ETF Bot V4 error</b>\n{exc}")
        time.sleep(sleep_seconds)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="XTB ETF Bot V4")
    p.add_argument("--config", default=str(DEFAULT_CONFIG), help="Path to config.json")
    p.add_argument("--state", default=str(DEFAULT_STATE), help="Path to state.json")
    p.add_argument("--once", action="store_true", help="Run one scan and exit")
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    config_path = Path(args.config)
    state_path = Path(args.state)
    if args.once:
        run_once(config_path, state_path)
    else:
        run_loop(config_path, state_path)
