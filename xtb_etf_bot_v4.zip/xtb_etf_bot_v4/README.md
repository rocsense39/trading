# XTB ETF Bot V4

Clean portfolio-first ETF alert bot. It does not place real XTB orders; it creates disciplined manual XTB instructions with sizing, entry, SL and TP.

## Run in Colab

```python
%cd /content
!rm -rf trading
!git clone https://github.com/rocsense39/trading.git
%cd /content/trading
```

Upload/copy this V4 folder or files into `/content/trading`, then:

```python
!pip install -r xtb_etf_bot_v4/requirements.txt
!python xtb_etf_bot_v4/main.py --once
```

For Telegram:

```python
import os, getpass
os.environ["TELEGRAM_TOKEN"] = getpass.getpass("TELEGRAM_TOKEN: ")
os.environ["TELEGRAM_CHAT_ID"] = getpass.getpass("TELEGRAM_CHAT_ID: ")
```

Then:

```python
!python xtb_etf_bot_v4/main.py
```

## Key fix versus V3

V4 has one config source. It never silently falls back to `min_order_eur=25` or `cash_reserve_pct=0.10` if your config says otherwise.
